﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Takehome_Week3
{
    public partial class Form1 : Form
    {
        List<string> usernames = new List<string>();
        List<string> passwords = new List<string>();
        List<int> saldo = new List<int>();
        int urutan;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel_login.BackColor = Color.FromArgb(80, 0, 0, 0);
            Register.BackColor = Color.FromArgb(80, 0, 0, 0);
            panel_saldo.BackColor = Color.FromArgb(80, 0, 0, 0);
            panel_withdraw.BackColor = Color.FromArgb(80, 0, 0, 0);
            panel_deposit.BackColor = Color.FromArgb(80, 0, 0, 0);
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            int count = 0;
            bool pass = false;
            urutan=0;
            foreach (string s in usernames)
            {
                if (tb_username.Text == s)
                {
                    urutan = count;
                    pass = true;
                }
                count++;
            }
            if (pass == false)
            {
                MessageBox.Show("Cannot found the account you're looking for,please try again");
            }
            else
            {
                if (passwords[urutan] != tb_password.Text)
                {
                    pass = false;
                    MessageBox.Show("Incorrect Passwords,Please Try Again");
                }
            }
            if (pass == true)
            {
                MessageBox.Show("Welcome " + tb_username.Text);
                panel_login.Visible = false;
                panel_saldo.Visible = true;
                string format = saldo[urutan].ToString("N0");
                nominal_lbl.Text = "Rp. "+format+",00";
                tb_password.Clear();
                tb_username.Clear();
            }
        }

        private void lbl_register_Click(object sender, EventArgs e)
        {
            tb_password.Clear();
            tb_username.Clear();
            Register.Visible = true;
        }

        private void register_button_Click(object sender, EventArgs e)
        {
            if (usernames.Contains(tb_regist_username.Text))
            {
                MessageBox.Show("Sorry, this accounts already exists");
            }
            else
            {
                usernames.Add(tb_regist_username.Text);
                passwords.Add(tb_regist_password.Text);
                saldo.Add(0);
                MessageBox.Show("Your Acoount is Created, WELCOME TO UC BANK MEMBER");
                Register.Visible = false;
                panel_login.Visible = true;
                tb_regist_username.Clear();
                tb_regist_password.Clear();
            }
        }

        private void back_regist_but_Click(object sender, EventArgs e)
        {
            tb_regist_username.Clear();
            tb_regist_password.Clear();
            Register.Visible = false;
            panel_login.Visible= true;
        }

        private void exit_but_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void logout_Click(object sender, EventArgs e)
        {
            tb_withdraw.Clear();
            tb_deposit.Clear();
            panel_withdraw.Visible = false;
            panel_deposit.Visible = false;
            panel_saldo.Visible = false;
            panel_login.Visible = true;
        }

        private void deposit_but_Click(object sender, EventArgs e)
        {
            panel_saldo.Visible = false;
            panel_deposit.Visible = true;
            lbl_deposit_saldo.Text = "Rp." + saldo[urutan].ToString("N0") + ",00";
        }

        private void withdraw_but_Click(object sender, EventArgs e)
        {
            panel_saldo.Visible=false;
            panel_withdraw.Visible=true;
            saldo_lbl_withdraw.Text = "Rp." + saldo[urutan].ToString("N0") + ",00";
        }

        private void withdraw_button_2_Click(object sender, EventArgs e)
        {
            string tbwithdraw = tb_withdraw.Text.Replace(".", "");
            if (int.TryParse(tbwithdraw,out int number))
            {
                int withdraw = Convert.ToInt32(tbwithdraw);
                if (saldo[urutan] >= withdraw)
                {
                    saldo[urutan] = saldo[urutan]-withdraw;
                    MessageBox.Show("Successfully withdraw Rp." + withdraw.ToString("N0") + ",00 from your account");
                    tb_withdraw.Clear();
                    saldo_lbl_withdraw.Text = "Rp." + saldo[urutan].ToString("N0") + ",00";
                }
                else
                {
                    MessageBox.Show("Sorry, insufficient balance");
                }
            }
            else
            {
                MessageBox.Show("Sorry,Withdraw amount must only be numbers");
            }
        }

        private void back_button_withdraw_Click(object sender, EventArgs e)
        {
            tb_withdraw.Clear();
            panel_withdraw.Visible = false;
            panel_saldo.Visible=true;
            nominal_lbl.Text = "Rp." + saldo[urutan].ToString("N0") + ",00";
        }

        private void deposit_button_2_Click(object sender, EventArgs e)
        {
            string deposits = tb_deposit.Text.Replace(".","");
            if (int.TryParse(deposits, out int number))
            {
                int deposit = Convert.ToInt32(deposits);
                if (deposit<=0)
                {
                    MessageBox.Show("Sorry, insufficient Ammount");
                }
                else
                {
                    saldo[urutan] = saldo[urutan] + deposit;
                    MessageBox.Show("Successfully deposit Rp." + deposit.ToString("N0") + ",00 from your account");
                    tb_deposit.Clear();
                    lbl_deposit_saldo.Text = "Rp." + saldo[urutan].ToString("N0") + ",00";
                }
            }
            else
            {
                MessageBox.Show("Sorry,Deposit amount must only be numbers");
            }
        }

        private void back_button_deposit_Click(object sender, EventArgs e)
        {
            tb_deposit.Clear();
            panel_deposit.Visible = false;
            panel_saldo.Visible = true;
            nominal_lbl.Text = "Rp." + saldo[urutan].ToString("N0") + ",00";
        }
    }
}
