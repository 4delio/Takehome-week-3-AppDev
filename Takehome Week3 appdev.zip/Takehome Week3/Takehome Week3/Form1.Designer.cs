﻿namespace Takehome_Week3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_login = new System.Windows.Forms.Panel();
            this.Register = new System.Windows.Forms.Panel();
            this.back_regist_but = new System.Windows.Forms.Button();
            this.register_button = new System.Windows.Forms.Button();
            this.tb_regist_password = new System.Windows.Forms.TextBox();
            this.tb_regist_username = new System.Windows.Forms.TextBox();
            this.password_register_lbl = new System.Windows.Forms.Label();
            this.username_regist_label = new System.Windows.Forms.Label();
            this.regist_label = new System.Windows.Forms.Label();
            this.lbl_or = new System.Windows.Forms.Label();
            this.lbl_register = new System.Windows.Forms.Label();
            this.btn_login = new System.Windows.Forms.Button();
            this.tb_password = new System.Windows.Forms.TextBox();
            this.tb_username = new System.Windows.Forms.TextBox();
            this.password = new System.Windows.Forms.Label();
            this.username = new System.Windows.Forms.Label();
            this.UCBANK = new System.Windows.Forms.Label();
            this.exit_but = new System.Windows.Forms.Button();
            this.panel_saldo = new System.Windows.Forms.Panel();
            this.panel_withdraw = new System.Windows.Forms.Panel();
            this.tb_withdraw = new System.Windows.Forms.TextBox();
            this.saldo_lbl_withdraw = new System.Windows.Forms.Label();
            this.ucbank_lbl_withdraw = new System.Windows.Forms.Label();
            this.back_button_withdraw = new System.Windows.Forms.Button();
            this.withdraw_button_2 = new System.Windows.Forms.Button();
            this.ballance_lbl_withdraw = new System.Windows.Forms.Label();
            this.nominal_lbl = new System.Windows.Forms.Label();
            this.ucbank_lbl = new System.Windows.Forms.Label();
            this.deposit_but = new System.Windows.Forms.Button();
            this.logout_but = new System.Windows.Forms.Button();
            this.withdraw_but = new System.Windows.Forms.Button();
            this.balance_lbl = new System.Windows.Forms.Label();
            this.panel_deposit = new System.Windows.Forms.Panel();
            this.tb_deposit = new System.Windows.Forms.TextBox();
            this.lbl_deposit_saldo = new System.Windows.Forms.Label();
            this.lbl_ucbank_deposit = new System.Windows.Forms.Label();
            this.back_button_deposit = new System.Windows.Forms.Button();
            this.deposit_button_2 = new System.Windows.Forms.Button();
            this.lbl_balance_deposit = new System.Windows.Forms.Label();
            this.button_logout_deposit = new System.Windows.Forms.Button();
            this.button_logout_withdraw = new System.Windows.Forms.Button();
            this.panel_login.SuspendLayout();
            this.Register.SuspendLayout();
            this.panel_saldo.SuspendLayout();
            this.panel_withdraw.SuspendLayout();
            this.panel_deposit.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_login
            // 
            this.panel_login.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel_login.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel_login.BackColor = System.Drawing.Color.Transparent;
            this.panel_login.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_login.Controls.Add(this.Register);
            this.panel_login.Controls.Add(this.lbl_or);
            this.panel_login.Controls.Add(this.lbl_register);
            this.panel_login.Controls.Add(this.btn_login);
            this.panel_login.Controls.Add(this.tb_password);
            this.panel_login.Controls.Add(this.tb_username);
            this.panel_login.Controls.Add(this.password);
            this.panel_login.Controls.Add(this.username);
            this.panel_login.Controls.Add(this.UCBANK);
            this.panel_login.Controls.Add(this.exit_but);
            this.panel_login.Location = new System.Drawing.Point(12, 21);
            this.panel_login.Name = "panel_login";
            this.panel_login.Size = new System.Drawing.Size(765, 400);
            this.panel_login.TabIndex = 1;
            // 
            // Register
            // 
            this.Register.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Register.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.Register.BackColor = System.Drawing.Color.Transparent;
            this.Register.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Register.Controls.Add(this.back_regist_but);
            this.Register.Controls.Add(this.register_button);
            this.Register.Controls.Add(this.tb_regist_password);
            this.Register.Controls.Add(this.tb_regist_username);
            this.Register.Controls.Add(this.password_register_lbl);
            this.Register.Controls.Add(this.username_regist_label);
            this.Register.Controls.Add(this.regist_label);
            this.Register.Location = new System.Drawing.Point(-1, -5);
            this.Register.Name = "Register";
            this.Register.Size = new System.Drawing.Size(765, 400);
            this.Register.TabIndex = 8;
            this.Register.Visible = false;
            // 
            // back_regist_but
            // 
            this.back_regist_but.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back_regist_but.Location = new System.Drawing.Point(28, 330);
            this.back_regist_but.Name = "back_regist_but";
            this.back_regist_but.Size = new System.Drawing.Size(96, 41);
            this.back_regist_but.TabIndex = 6;
            this.back_regist_but.Text = "Back";
            this.back_regist_but.UseVisualStyleBackColor = true;
            this.back_regist_but.Click += new System.EventHandler(this.back_regist_but_Click);
            // 
            // register_button
            // 
            this.register_button.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.register_button.Location = new System.Drawing.Point(263, 254);
            this.register_button.Name = "register_button";
            this.register_button.Size = new System.Drawing.Size(243, 48);
            this.register_button.TabIndex = 5;
            this.register_button.Text = "Create Account";
            this.register_button.UseVisualStyleBackColor = true;
            this.register_button.Click += new System.EventHandler(this.register_button_Click);
            // 
            // tb_regist_password
            // 
            this.tb_regist_password.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_regist_password.Location = new System.Drawing.Point(185, 187);
            this.tb_regist_password.Name = "tb_regist_password";
            this.tb_regist_password.Size = new System.Drawing.Size(492, 39);
            this.tb_regist_password.TabIndex = 4;
            // 
            // tb_regist_username
            // 
            this.tb_regist_username.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_regist_username.Location = new System.Drawing.Point(185, 127);
            this.tb_regist_username.Name = "tb_regist_username";
            this.tb_regist_username.Size = new System.Drawing.Size(492, 39);
            this.tb_regist_username.TabIndex = 3;
            // 
            // password_register_lbl
            // 
            this.password_register_lbl.AutoSize = true;
            this.password_register_lbl.BackColor = System.Drawing.Color.Transparent;
            this.password_register_lbl.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.password_register_lbl.ForeColor = System.Drawing.Color.White;
            this.password_register_lbl.Location = new System.Drawing.Point(23, 196);
            this.password_register_lbl.Name = "password_register_lbl";
            this.password_register_lbl.Size = new System.Drawing.Size(128, 30);
            this.password_register_lbl.TabIndex = 2;
            this.password_register_lbl.Text = "Password";
            // 
            // username_regist_label
            // 
            this.username_regist_label.AutoSize = true;
            this.username_regist_label.BackColor = System.Drawing.Color.Transparent;
            this.username_regist_label.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.username_regist_label.ForeColor = System.Drawing.Color.White;
            this.username_regist_label.Location = new System.Drawing.Point(23, 127);
            this.username_regist_label.Name = "username_regist_label";
            this.username_regist_label.Size = new System.Drawing.Size(133, 30);
            this.username_regist_label.TabIndex = 1;
            this.username_regist_label.Text = "Username";
            // 
            // regist_label
            // 
            this.regist_label.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.regist_label.AutoSize = true;
            this.regist_label.BackColor = System.Drawing.Color.Transparent;
            this.regist_label.Font = new System.Drawing.Font("Mongolian Baiti", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regist_label.ForeColor = System.Drawing.Color.White;
            this.regist_label.Location = new System.Drawing.Point(230, 0);
            this.regist_label.Name = "regist_label";
            this.regist_label.Size = new System.Drawing.Size(309, 85);
            this.regist_label.TabIndex = 0;
            this.regist_label.Text = "Register";
            // 
            // lbl_or
            // 
            this.lbl_or.AutoSize = true;
            this.lbl_or.BackColor = System.Drawing.Color.Transparent;
            this.lbl_or.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_or.ForeColor = System.Drawing.Color.White;
            this.lbl_or.Location = new System.Drawing.Point(353, 300);
            this.lbl_or.Name = "lbl_or";
            this.lbl_or.Size = new System.Drawing.Size(38, 30);
            this.lbl_or.TabIndex = 7;
            this.lbl_or.Text = "or";
            // 
            // lbl_register
            // 
            this.lbl_register.AutoSize = true;
            this.lbl_register.BackColor = System.Drawing.Color.Gainsboro;
            this.lbl_register.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_register.ForeColor = System.Drawing.Color.Black;
            this.lbl_register.Location = new System.Drawing.Point(225, 330);
            this.lbl_register.Name = "lbl_register";
            this.lbl_register.Size = new System.Drawing.Size(302, 30);
            this.lbl_register.TabIndex = 6;
            this.lbl_register.Text = "Click Here To Register ";
            this.lbl_register.Click += new System.EventHandler(this.lbl_register_Click);
            // 
            // btn_login
            // 
            this.btn_login.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_login.Location = new System.Drawing.Point(310, 254);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(143, 48);
            this.btn_login.TabIndex = 5;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // tb_password
            // 
            this.tb_password.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_password.Location = new System.Drawing.Point(185, 187);
            this.tb_password.Name = "tb_password";
            this.tb_password.Size = new System.Drawing.Size(492, 39);
            this.tb_password.TabIndex = 4;
            // 
            // tb_username
            // 
            this.tb_username.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_username.Location = new System.Drawing.Point(185, 127);
            this.tb_username.Name = "tb_username";
            this.tb_username.Size = new System.Drawing.Size(492, 39);
            this.tb_username.TabIndex = 3;
            // 
            // password
            // 
            this.password.AutoSize = true;
            this.password.BackColor = System.Drawing.Color.Transparent;
            this.password.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.password.ForeColor = System.Drawing.Color.White;
            this.password.Location = new System.Drawing.Point(23, 196);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(128, 30);
            this.password.TabIndex = 2;
            this.password.Text = "Password";
            // 
            // username
            // 
            this.username.AutoSize = true;
            this.username.BackColor = System.Drawing.Color.Transparent;
            this.username.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.username.ForeColor = System.Drawing.Color.White;
            this.username.Location = new System.Drawing.Point(23, 127);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(133, 30);
            this.username.TabIndex = 1;
            this.username.Text = "Username";
            // 
            // UCBANK
            // 
            this.UCBANK.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.UCBANK.AutoSize = true;
            this.UCBANK.BackColor = System.Drawing.Color.Transparent;
            this.UCBANK.Font = new System.Drawing.Font("Mongolian Baiti", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UCBANK.ForeColor = System.Drawing.Color.White;
            this.UCBANK.Location = new System.Drawing.Point(170, -1);
            this.UCBANK.Name = "UCBANK";
            this.UCBANK.Size = new System.Drawing.Size(398, 85);
            this.UCBANK.TabIndex = 0;
            this.UCBANK.Text = "UC BANK";
            // 
            // exit_but
            // 
            this.exit_but.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit_but.Location = new System.Drawing.Point(3, 348);
            this.exit_but.Name = "exit_but";
            this.exit_but.Size = new System.Drawing.Size(94, 32);
            this.exit_but.TabIndex = 9;
            this.exit_but.Text = "EXIT";
            this.exit_but.UseVisualStyleBackColor = true;
            this.exit_but.Click += new System.EventHandler(this.exit_but_Click);
            // 
            // panel_saldo
            // 
            this.panel_saldo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel_saldo.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel_saldo.BackColor = System.Drawing.Color.Transparent;
            this.panel_saldo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_saldo.Controls.Add(this.nominal_lbl);
            this.panel_saldo.Controls.Add(this.ucbank_lbl);
            this.panel_saldo.Controls.Add(this.deposit_but);
            this.panel_saldo.Controls.Add(this.logout_but);
            this.panel_saldo.Controls.Add(this.withdraw_but);
            this.panel_saldo.Controls.Add(this.balance_lbl);
            this.panel_saldo.Location = new System.Drawing.Point(11, 12);
            this.panel_saldo.Name = "panel_saldo";
            this.panel_saldo.Size = new System.Drawing.Size(765, 432);
            this.panel_saldo.TabIndex = 9;
            this.panel_saldo.Visible = false;
            // 
            // panel_withdraw
            // 
            this.panel_withdraw.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel_withdraw.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel_withdraw.BackColor = System.Drawing.Color.Transparent;
            this.panel_withdraw.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_withdraw.Controls.Add(this.button_logout_withdraw);
            this.panel_withdraw.Controls.Add(this.tb_withdraw);
            this.panel_withdraw.Controls.Add(this.saldo_lbl_withdraw);
            this.panel_withdraw.Controls.Add(this.ucbank_lbl_withdraw);
            this.panel_withdraw.Controls.Add(this.back_button_withdraw);
            this.panel_withdraw.Controls.Add(this.withdraw_button_2);
            this.panel_withdraw.Controls.Add(this.ballance_lbl_withdraw);
            this.panel_withdraw.Location = new System.Drawing.Point(10, 8);
            this.panel_withdraw.Name = "panel_withdraw";
            this.panel_withdraw.Size = new System.Drawing.Size(765, 432);
            this.panel_withdraw.TabIndex = 10;
            this.panel_withdraw.Visible = false;
            // 
            // tb_withdraw
            // 
            this.tb_withdraw.Font = new System.Drawing.Font("Mongolian Baiti", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_withdraw.Location = new System.Drawing.Point(88, 211);
            this.tb_withdraw.Name = "tb_withdraw";
            this.tb_withdraw.Size = new System.Drawing.Size(606, 77);
            this.tb_withdraw.TabIndex = 10;
            // 
            // saldo_lbl_withdraw
            // 
            this.saldo_lbl_withdraw.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.saldo_lbl_withdraw.AutoEllipsis = true;
            this.saldo_lbl_withdraw.AutoSize = true;
            this.saldo_lbl_withdraw.BackColor = System.Drawing.Color.Transparent;
            this.saldo_lbl_withdraw.Font = new System.Drawing.Font("Mongolian Baiti", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saldo_lbl_withdraw.ForeColor = System.Drawing.Color.White;
            this.saldo_lbl_withdraw.Location = new System.Drawing.Point(274, 125);
            this.saldo_lbl_withdraw.Name = "saldo_lbl_withdraw";
            this.saldo_lbl_withdraw.Size = new System.Drawing.Size(180, 50);
            this.saldo_lbl_withdraw.TabIndex = 9;
            this.saldo_lbl_withdraw.Text = "Rp.0,00";
            // 
            // ucbank_lbl_withdraw
            // 
            this.ucbank_lbl_withdraw.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ucbank_lbl_withdraw.AutoSize = true;
            this.ucbank_lbl_withdraw.BackColor = System.Drawing.Color.Transparent;
            this.ucbank_lbl_withdraw.Font = new System.Drawing.Font("Mongolian Baiti", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ucbank_lbl_withdraw.ForeColor = System.Drawing.Color.White;
            this.ucbank_lbl_withdraw.Location = new System.Drawing.Point(170, 16);
            this.ucbank_lbl_withdraw.Name = "ucbank_lbl_withdraw";
            this.ucbank_lbl_withdraw.Size = new System.Drawing.Size(398, 85);
            this.ucbank_lbl_withdraw.TabIndex = 8;
            this.ucbank_lbl_withdraw.Text = "UC BANK";
            // 
            // back_button_withdraw
            // 
            this.back_button_withdraw.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back_button_withdraw.Location = new System.Drawing.Point(28, 330);
            this.back_button_withdraw.Name = "back_button_withdraw";
            this.back_button_withdraw.Size = new System.Drawing.Size(123, 41);
            this.back_button_withdraw.TabIndex = 6;
            this.back_button_withdraw.Text = "Back";
            this.back_button_withdraw.UseVisualStyleBackColor = true;
            this.back_button_withdraw.Click += new System.EventHandler(this.back_button_withdraw_Click);
            // 
            // withdraw_button_2
            // 
            this.withdraw_button_2.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.withdraw_button_2.Location = new System.Drawing.Point(294, 295);
            this.withdraw_button_2.Name = "withdraw_button_2";
            this.withdraw_button_2.Size = new System.Drawing.Size(168, 57);
            this.withdraw_button_2.TabIndex = 5;
            this.withdraw_button_2.Text = "Withdraw";
            this.withdraw_button_2.UseVisualStyleBackColor = true;
            this.withdraw_button_2.Click += new System.EventHandler(this.withdraw_button_2_Click);
            // 
            // ballance_lbl_withdraw
            // 
            this.ballance_lbl_withdraw.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ballance_lbl_withdraw.AutoSize = true;
            this.ballance_lbl_withdraw.BackColor = System.Drawing.Color.Transparent;
            this.ballance_lbl_withdraw.Font = new System.Drawing.Font("Mongolian Baiti", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ballance_lbl_withdraw.ForeColor = System.Drawing.Color.White;
            this.ballance_lbl_withdraw.Location = new System.Drawing.Point(46, 125);
            this.ballance_lbl_withdraw.Name = "ballance_lbl_withdraw";
            this.ballance_lbl_withdraw.Size = new System.Drawing.Size(222, 50);
            this.ballance_lbl_withdraw.TabIndex = 0;
            this.ballance_lbl_withdraw.Text = "Ballance :";
            // 
            // nominal_lbl
            // 
            this.nominal_lbl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nominal_lbl.AutoEllipsis = true;
            this.nominal_lbl.AutoSize = true;
            this.nominal_lbl.BackColor = System.Drawing.Color.Transparent;
            this.nominal_lbl.Font = new System.Drawing.Font("Mongolian Baiti", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nominal_lbl.ForeColor = System.Drawing.Color.White;
            this.nominal_lbl.Location = new System.Drawing.Point(274, 125);
            this.nominal_lbl.Name = "nominal_lbl";
            this.nominal_lbl.Size = new System.Drawing.Size(180, 50);
            this.nominal_lbl.TabIndex = 9;
            this.nominal_lbl.Text = "Rp.0,00";
            // 
            // ucbank_lbl
            // 
            this.ucbank_lbl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ucbank_lbl.AutoSize = true;
            this.ucbank_lbl.BackColor = System.Drawing.Color.Transparent;
            this.ucbank_lbl.Font = new System.Drawing.Font("Mongolian Baiti", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ucbank_lbl.ForeColor = System.Drawing.Color.White;
            this.ucbank_lbl.Location = new System.Drawing.Point(170, 16);
            this.ucbank_lbl.Name = "ucbank_lbl";
            this.ucbank_lbl.Size = new System.Drawing.Size(398, 85);
            this.ucbank_lbl.TabIndex = 8;
            this.ucbank_lbl.Text = "UC BANK";
            // 
            // deposit_but
            // 
            this.deposit_but.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deposit_but.Location = new System.Drawing.Point(449, 231);
            this.deposit_but.Name = "deposit_but";
            this.deposit_but.Size = new System.Drawing.Size(169, 57);
            this.deposit_but.TabIndex = 7;
            this.deposit_but.Text = "Deposit";
            this.deposit_but.UseVisualStyleBackColor = true;
            this.deposit_but.Click += new System.EventHandler(this.deposit_but_Click);
            // 
            // logout_but
            // 
            this.logout_but.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logout_but.Location = new System.Drawing.Point(28, 330);
            this.logout_but.Name = "logout_but";
            this.logout_but.Size = new System.Drawing.Size(123, 41);
            this.logout_but.TabIndex = 6;
            this.logout_but.Text = "Logout";
            this.logout_but.UseVisualStyleBackColor = true;
            this.logout_but.Click += new System.EventHandler(this.logout_Click);
            // 
            // withdraw_but
            // 
            this.withdraw_but.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.withdraw_but.Location = new System.Drawing.Point(108, 231);
            this.withdraw_but.Name = "withdraw_but";
            this.withdraw_but.Size = new System.Drawing.Size(168, 57);
            this.withdraw_but.TabIndex = 5;
            this.withdraw_but.Text = "Withdraw";
            this.withdraw_but.UseVisualStyleBackColor = true;
            this.withdraw_but.Click += new System.EventHandler(this.withdraw_but_Click);
            // 
            // balance_lbl
            // 
            this.balance_lbl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.balance_lbl.AutoSize = true;
            this.balance_lbl.BackColor = System.Drawing.Color.Transparent;
            this.balance_lbl.Font = new System.Drawing.Font("Mongolian Baiti", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.balance_lbl.ForeColor = System.Drawing.Color.White;
            this.balance_lbl.Location = new System.Drawing.Point(46, 125);
            this.balance_lbl.Name = "balance_lbl";
            this.balance_lbl.Size = new System.Drawing.Size(222, 50);
            this.balance_lbl.TabIndex = 0;
            this.balance_lbl.Text = "Ballance :";
            // 
            // panel_deposit
            // 
            this.panel_deposit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel_deposit.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel_deposit.BackColor = System.Drawing.Color.Transparent;
            this.panel_deposit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_deposit.Controls.Add(this.button_logout_deposit);
            this.panel_deposit.Controls.Add(this.tb_deposit);
            this.panel_deposit.Controls.Add(this.lbl_deposit_saldo);
            this.panel_deposit.Controls.Add(this.lbl_ucbank_deposit);
            this.panel_deposit.Controls.Add(this.back_button_deposit);
            this.panel_deposit.Controls.Add(this.deposit_button_2);
            this.panel_deposit.Controls.Add(this.lbl_balance_deposit);
            this.panel_deposit.Location = new System.Drawing.Point(11, 4);
            this.panel_deposit.Name = "panel_deposit";
            this.panel_deposit.Size = new System.Drawing.Size(765, 432);
            this.panel_deposit.TabIndex = 11;
            this.panel_deposit.Visible = false;
            // 
            // tb_deposit
            // 
            this.tb_deposit.Font = new System.Drawing.Font("Mongolian Baiti", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_deposit.Location = new System.Drawing.Point(88, 211);
            this.tb_deposit.Name = "tb_deposit";
            this.tb_deposit.Size = new System.Drawing.Size(606, 77);
            this.tb_deposit.TabIndex = 10;
            // 
            // lbl_deposit_saldo
            // 
            this.lbl_deposit_saldo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_deposit_saldo.AutoEllipsis = true;
            this.lbl_deposit_saldo.AutoSize = true;
            this.lbl_deposit_saldo.BackColor = System.Drawing.Color.Transparent;
            this.lbl_deposit_saldo.Font = new System.Drawing.Font("Mongolian Baiti", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_deposit_saldo.ForeColor = System.Drawing.Color.White;
            this.lbl_deposit_saldo.Location = new System.Drawing.Point(274, 125);
            this.lbl_deposit_saldo.Name = "lbl_deposit_saldo";
            this.lbl_deposit_saldo.Size = new System.Drawing.Size(180, 50);
            this.lbl_deposit_saldo.TabIndex = 9;
            this.lbl_deposit_saldo.Text = "Rp.0,00";
            // 
            // lbl_ucbank_deposit
            // 
            this.lbl_ucbank_deposit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_ucbank_deposit.AutoSize = true;
            this.lbl_ucbank_deposit.BackColor = System.Drawing.Color.Transparent;
            this.lbl_ucbank_deposit.Font = new System.Drawing.Font("Mongolian Baiti", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ucbank_deposit.ForeColor = System.Drawing.Color.White;
            this.lbl_ucbank_deposit.Location = new System.Drawing.Point(170, 16);
            this.lbl_ucbank_deposit.Name = "lbl_ucbank_deposit";
            this.lbl_ucbank_deposit.Size = new System.Drawing.Size(398, 85);
            this.lbl_ucbank_deposit.TabIndex = 8;
            this.lbl_ucbank_deposit.Text = "UC BANK";
            // 
            // back_button_deposit
            // 
            this.back_button_deposit.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back_button_deposit.Location = new System.Drawing.Point(28, 330);
            this.back_button_deposit.Name = "back_button_deposit";
            this.back_button_deposit.Size = new System.Drawing.Size(123, 41);
            this.back_button_deposit.TabIndex = 6;
            this.back_button_deposit.Text = "Back";
            this.back_button_deposit.UseVisualStyleBackColor = true;
            this.back_button_deposit.Click += new System.EventHandler(this.back_button_deposit_Click);
            // 
            // deposit_button_2
            // 
            this.deposit_button_2.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deposit_button_2.Location = new System.Drawing.Point(294, 295);
            this.deposit_button_2.Name = "deposit_button_2";
            this.deposit_button_2.Size = new System.Drawing.Size(168, 57);
            this.deposit_button_2.TabIndex = 5;
            this.deposit_button_2.Text = "Deposit";
            this.deposit_button_2.UseVisualStyleBackColor = true;
            this.deposit_button_2.Click += new System.EventHandler(this.deposit_button_2_Click);
            // 
            // lbl_balance_deposit
            // 
            this.lbl_balance_deposit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_balance_deposit.AutoSize = true;
            this.lbl_balance_deposit.BackColor = System.Drawing.Color.Transparent;
            this.lbl_balance_deposit.Font = new System.Drawing.Font("Mongolian Baiti", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_balance_deposit.ForeColor = System.Drawing.Color.White;
            this.lbl_balance_deposit.Location = new System.Drawing.Point(46, 125);
            this.lbl_balance_deposit.Name = "lbl_balance_deposit";
            this.lbl_balance_deposit.Size = new System.Drawing.Size(222, 50);
            this.lbl_balance_deposit.TabIndex = 0;
            this.lbl_balance_deposit.Text = "Ballance :";
            // 
            // button_logout_deposit
            // 
            this.button_logout_deposit.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_logout_deposit.Location = new System.Drawing.Point(26, 377);
            this.button_logout_deposit.Name = "button_logout_deposit";
            this.button_logout_deposit.Size = new System.Drawing.Size(123, 41);
            this.button_logout_deposit.TabIndex = 11;
            this.button_logout_deposit.Text = "Logout";
            this.button_logout_deposit.UseVisualStyleBackColor = true;
            this.button_logout_deposit.Click += new System.EventHandler(this.logout_Click);
            // 
            // button_logout_withdraw
            // 
            this.button_logout_withdraw.Font = new System.Drawing.Font("Mongolian Baiti", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_logout_withdraw.Location = new System.Drawing.Point(28, 377);
            this.button_logout_withdraw.Name = "button_logout_withdraw";
            this.button_logout_withdraw.Size = new System.Drawing.Size(123, 41);
            this.button_logout_withdraw.TabIndex = 12;
            this.button_logout_withdraw.Text = "Logout";
            this.button_logout_withdraw.UseVisualStyleBackColor = true;
            this.button_logout_withdraw.Click += new System.EventHandler(this.logout_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gold;
            this.BackgroundImage = global::Takehome_Week3.Properties.Resources.LOGO_UC_FIX_SEP_2021_02;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel_withdraw);
            this.Controls.Add(this.panel_deposit);
            this.Controls.Add(this.panel_saldo);
            this.Controls.Add(this.panel_login);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "UC_BANK by adelio surya putra pratama";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel_login.ResumeLayout(false);
            this.panel_login.PerformLayout();
            this.Register.ResumeLayout(false);
            this.Register.PerformLayout();
            this.panel_saldo.ResumeLayout(false);
            this.panel_saldo.PerformLayout();
            this.panel_withdraw.ResumeLayout(false);
            this.panel_withdraw.PerformLayout();
            this.panel_deposit.ResumeLayout(false);
            this.panel_deposit.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel_login;
        private System.Windows.Forms.Label UCBANK;
        private System.Windows.Forms.Label password;
        private System.Windows.Forms.Label username;
        private System.Windows.Forms.Label lbl_register;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.TextBox tb_password;
        private System.Windows.Forms.TextBox tb_username;
        private System.Windows.Forms.Label lbl_or;
        private System.Windows.Forms.Panel Register;
        private System.Windows.Forms.Button register_button;
        private System.Windows.Forms.TextBox tb_regist_password;
        private System.Windows.Forms.TextBox tb_regist_username;
        private System.Windows.Forms.Label password_register_lbl;
        private System.Windows.Forms.Label username_regist_label;
        private System.Windows.Forms.Label regist_label;
        private System.Windows.Forms.Button back_regist_but;
        private System.Windows.Forms.Panel panel_saldo;
        private System.Windows.Forms.Button logout_but;
        private System.Windows.Forms.Button withdraw_but;
        private System.Windows.Forms.Label balance_lbl;
        private System.Windows.Forms.Button deposit_but;
        private System.Windows.Forms.Label nominal_lbl;
        private System.Windows.Forms.Label ucbank_lbl;
        private System.Windows.Forms.Button exit_but;
        private System.Windows.Forms.Panel panel_withdraw;
        private System.Windows.Forms.Label saldo_lbl_withdraw;
        private System.Windows.Forms.Label ucbank_lbl_withdraw;
        private System.Windows.Forms.Button back_button_withdraw;
        private System.Windows.Forms.Button withdraw_button_2;
        private System.Windows.Forms.Label ballance_lbl_withdraw;
        private System.Windows.Forms.TextBox tb_withdraw;
        private System.Windows.Forms.Panel panel_deposit;
        private System.Windows.Forms.TextBox tb_deposit;
        private System.Windows.Forms.Label lbl_deposit_saldo;
        private System.Windows.Forms.Label lbl_ucbank_deposit;
        private System.Windows.Forms.Button back_button_deposit;
        private System.Windows.Forms.Button deposit_button_2;
        private System.Windows.Forms.Label lbl_balance_deposit;
        private System.Windows.Forms.Button button_logout_deposit;
        private System.Windows.Forms.Button button_logout_withdraw;
    }
}

